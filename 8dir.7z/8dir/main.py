import pygame
import random
import math

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# Colors
RED = (255, 0, 0)
WHITE = (255, 255, 255)

# Load images
hero_image = pygame.image.load("hero.png")
zombie_image = pygame.image.load("zombie.png")
floor_image = pygame.image.load("floor.png")

# Initialize screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Top-Down Shooter")

# Clock for controlling frame rate
clock = pygame.time.Clock()

# Score variable
score = 0
font = pygame.font.Font(None, 36)

# Classes
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = hero_image
        self.rect = self.image.get_rect()
        self.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        self.speed = 5

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.rect.x += self.speed
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self.rect.y += self.speed

    def rotate_to_mouse(self):
        mouse_pos = pygame.mouse.get_pos()
        dx, dy = mouse_pos[0] - self.rect.centerx, mouse_pos[1] - self.rect.centery
        angle = math.degrees(math.atan2(-dy, dx)) - 90
        self.image = pygame.transform.rotate(hero_image, angle)
        self.rect = self.image.get_rect(center=self.rect.center)

class Zombie(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = zombie_image
        self.rect = self.image.get_rect()
        self.rect.x = random.choice([0, SCREEN_WIDTH - self.rect.width])
        self.rect.y = random.choice([0, SCREEN_HEIGHT - self.rect.height])
        self.speed = 2

    def update(self):
        player_pos = player.rect.center
        direction = (player_pos[0] - self.rect.x, player_pos[1] - self.rect.y)
        length = math.hypot(*direction)
        direction = (direction[0] / length, direction[1] / length)
        self.rect.x += direction[0] * self.speed
        self.rect.y += direction[1] * self.speed

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction):
        super().__init__()
        self.image = pygame.Surface((5, 5))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = 10
        self.direction = direction

    def update(self):
        self.rect.x += self.direction[0] * self.speed
        self.rect.y += self.direction[1] * self.speed
        if self.rect.x < 0 or self.rect.x > SCREEN_WIDTH or self.rect.y < 0 or self.rect.y > SCREEN_HEIGHT:
            self.kill()

# Sprites groups
all_sprites = pygame.sprite.Group()
zombies = pygame.sprite.Group()
bullets = pygame.sprite.Group()

# Create player
player = Player()
all_sprites.add(player)

spawn_timer = 0
spawn_interval = 2000  # Spawn a new zombie every 2000 milliseconds (2 seconds)

# Game loop
running = True
while running:
    clock.tick(60)
    spawn_timer += clock.get_time()  # Increment the spawn timer

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                mouse_pos = pygame.mouse.get_pos()
                direction = (mouse_pos[0] - player.rect.centerx, mouse_pos[1] - player.rect.centery)
                length = math.hypot(*direction)
                direction = (direction[0] / length, direction[1] / length)
                bullet = Bullet(player.rect.centerx, player.rect.centery, direction)
                all_sprites.add(bullet)
                bullets.add(bullet)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button
                mouse_pos = pygame.mouse.get_pos()
                direction = (mouse_pos[0] - player.rect.centerx, mouse_pos[1] - player.rect.centery)
                length = math.hypot(*direction)
                direction = (direction[0] / length, direction[1] / length)
                bullet = Bullet(player.rect.centerx, player.rect.centery, direction)
                all_sprites.add(bullet)
                bullets.add(bullet)

    # Check if it's time to spawn a new zombie
    if spawn_timer >= spawn_interval:
        zombie = Zombie()
        all_sprites.add(zombie)
        zombies.add(zombie)
        spawn_timer = 0  # Reset the spawn timer

    player.update()
    player.rotate_to_mouse()  # Rotate player to face the mouse position
    all_sprites.update()

    # Check for collisions
    for bullet in pygame.sprite.groupcollide(bullets, zombies, True, True):
        score += 1  # Increment score when a zombie is hit

    # Draw the tiled floor
    for x in range(0, SCREEN_WIDTH, floor_image.get_width()):
        for y in range(0, SCREEN_HEIGHT, floor_image.get_height()):
            screen.blit(floor_image, (x, y))

    all_sprites.draw(screen)

    # Display score
    score_text = font.render(f'Score: {score}', True, WHITE)
    screen.blit(score_text, (10, 10))

    pygame.display.flip()

pygame.quit()
